

import java.sql.*;



public class LoginDao {
	public static boolean validate(String username, String passwd) {
		boolean status=false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/login","root","");
			PreparedStatement ps=con.prepareStatement("select * from username where username=? and "
					+ "passwd=?");
			ps.setString(1, username);
			ps.setString(2, passwd);
			ResultSet rs=ps.executeQuery();
			status=rs.next();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return status;
	}
     

}
